from setuptools import setup, find_packages

setup(
  name = 'fcryptor',
  version = '1',
  author = 'Omid Karimzade',
  author_email = 'omidekz@gmail.com',
  description = 'python package that encrypt/decrypt files by key.',

  license='MIT',
  keywords = ['file encrypt', 'file cryptography', 'file crypt', 'decrypt', 'fcrypt', 'file-crypt'],
  url = 'https://github.com/joelbarmettlerUZH/Scrapeasy',
  packages = find_packages(include=['fcrypt', 'fcrypt.*']),
  install_requires=[
          'cryptography'
  ],
  classifiers=[  # Optional
    # How mature is this project? Common values are
    #   3 - Alpha
    #   4 - Beta
    #   5 - Production/Stable
    'Development Status :: 3 - Alpha',

    # Indicate who your project is intended for
    'Intended Audience :: Developers',
    'Topic :: Security :: Cryptography',

    # Pick your license as you wish
    'License :: OSI Approved :: MIT License',

    # Specify the Python versions you support here. In particular, ensure
    # that you indicate whether you support Python 2, Python 3 or both.
    'Programming Language :: Python :: 3',
    'Programming Language :: Python :: 3.0',
    'Programming Language :: Python :: 3.1',
    'Programming Language :: Python :: 3.10',
    'Programming Language :: Python :: 3.2',
    'Programming Language :: Python :: 3.3',
    'Programming Language :: Python :: 3.4',
    'Programming Language :: Python :: 3.5',
    'Programming Language :: Python :: 3.6',
    'Programming Language :: Python :: 3.7',
    'Programming Language :: Python :: 3.8',
    'Programming Language :: Python :: 3.9',
  ],
)
